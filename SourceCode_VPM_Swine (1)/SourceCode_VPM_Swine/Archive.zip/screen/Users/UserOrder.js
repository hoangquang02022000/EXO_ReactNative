import { Button, Container, Content, Icon, Input, Item, Label, Picker, Text, Thumbnail } from 'native-base';
import React, { Component } from 'react';
import { Modal, View, StyleSheet, Alert, Platform } from 'react-native';
import Myheader from '../../components/Myheader';
import DateTimePicker from '@react-native-community/datetimepicker';
import { getErrorList } from '../../api/Device';
import { CurrentTime, GetUserLocal, TimeToString, VpmPushNotification } from '../../func';
import * as ImagePicker from 'expo-image-picker';
import { TouchableOpacity } from 'react-native-gesture-handler';
import { UserRequestFix } from '../../api/Order';
import ScanQR from './ScanQR';
import { isEmpty } from '../../components/Validate';
import Spinner from 'react-native-loading-spinner-overlay';

class UserOrder extends Component {
    state = {
        showDate: false,
        imgNumber: 0,
        submit: () => { },
        modal: false,
        images: [],
        errorList: [],
        scan: false,

        error_code: null,
        date: CurrentTime(),
        userid: null,
        db_name: null,
        mc_code: null,
        spinner: false
    }

    handleModal = () => {
        this.setState({ modal: !this.state.modal })
    }

    handleError = (error) => {
        this.setState({ error_code: error })
    }

    showDate = () => {
        this.setState({ showDate: true })
    }

    async componentDidMount() {
        let user = await GetUserLocal();

        this.setState({ userid: user.userid, db_name: user.db_name })
        getErrorList(user.db_name, res => {
            this.setState({ errorList: res })
        })
    }

    renderSelectedComponent = (number) => (
        <View style={styles.countBadge}>
            <Text style={styles.countBadgeText}>{number}</Text>
        </View>
    );
    updateHandler = (count, onSubmit) => {
        this.setState({ submit: onSubmit, imgNumber: count })
    };


    handleDateChange = (event, value) => {
        if (value !== undefined) {
            let fixDate = TimeToString(value);
            this.setState({ date: fixDate, showDate: false })
        } else {
            this.setState({ showDate: false })
        }

    }

    pickImage = async (number) => {
        let { images } = this.state;
        let result = await ImagePicker.launchImageLibraryAsync({
            mediaTypes: ImagePicker.MediaTypeOptions.Images,
            base64: true
        });
        if (!result.cancelled) {
            let uri = result.uri;
            let name = (result.uri).split('/').pop();
            let match = /\.(\w+)$/.exec(name);
            let type = match ? `image/${match[1]}` : `image`;
            let obj = { uri, name, type }

            switch (number) {
                case "0":
                    images[0] = obj;
                    break;
                case "1":
                    images[1] = obj;
                    break;
                case "2":
                    images[2] = obj;
                    break;
                default:
                    break;
            }
        }
        this.setState({ images })
    };

    handleMcCode = (mc_code) => {
        this.setState({ mc_code })
    }

    handleRequestFix = () => {

        let { userid, images, error_code, date, mc_code, db_name } = this.state;

        let checkMc_Code = isEmpty(mc_code, "thiết bị");
        if (!checkMc_Code) {
            return false;
        }
        let checkEr_code = isEmpty(error_code, "lỗi thiết bị");
        if (!checkEr_code) {
            return false;
        }

        if (images.length < 3) {
            Alert.alert("Thông báo", "Vui lòng chọn 3 ảnh");
            return false;
        }

        this.setState({ spinner: true });
        const formData = new FormData();
        images.forEach(item => {
            formData.append("files[]", item);
        })

        UserRequestFix(mc_code, error_code, date, userid, db_name, formData, res => {
            if (res === "success") {
                VpmPushNotification("2", "Có yêu cầu mới cần được duyệt");
                this.setState({ spinner: false });
                Alert.alert("Thông báo", "Gởi yêu cầu thành công");
                this.props.navigation.navigate("Status");
            } else {
                Alert.alert("Thông báo", res)
            }
        })

        setTimeout(() => {
            this.setState({ spinner: false })
        }, 3000);
    }
    showQRScan = () => {
        this.setState({ scan: true })
    }

    closeScreen = () => {
        this.setState({ scan: false })
    }

    scanResult = (data) => {
        this.setState({ scan: false, mc_code: data })
    }

    render() {

        let { date, errorList, error_code, images, mc_code, scan, showDate } = this.state;

        let viewErrorList = errorList.map((item, i) => {
            return <Picker.Item key={i} value={item.code} label={item.name_vn} />
        })
        return (
            <Container style={{ backgroundColor: "#f1f1f1" }}>
                <Myheader {...this.props} goBack={false} title="Đơn yêu cầu" />
                <Spinner
                    visible={this.state.spinner}
                    textContent={'Loading...'}
                />
                <Content>
                    <View style={{
                        backgroundColor: "#fff",
                        padding: 20,
                        margin: 15,
                        borderRadius: 15
                    }}>
                        <Item>
                            <Input defaultValue={mc_code} placeholder="Nhập mã" onChangeText={this.handleMcCode} />
                            <Button onPress={this.showQRScan} transparent icon><Icon name="qrcode-scan" type="MaterialCommunityIcons" /></Button>
                        </Item>
                        <Item picker>
                            <Picker placeholderStyle={{ paddingLeft: 0 }}
                                placeholder="Chọn một lỗi"
                                itemStyle={{ paddingLeft: 0 }}
                                itemTextStyle={{ paddingLeft: 0 }}
                                onValueChange={this.handleError}
                                selectedValue={error_code}
                                iosIcon={<Icon name="arrowright" type="AntDesign" />}>
                                {viewErrorList}
                            </Picker>
                        </Item>
                        <Label style={{ marginTop: 10, marginBottom: 10 }}>Chọn ngày hoàn thành</Label>
                        {
                            Platform.OS === "android" && <Button onPress={this.showDate} success><Icon name="calendar" /><Text>{date}</Text></Button>

                        }
                        {
                            Platform.OS === "ios" ? <DateTimePicker
                                testID="dateTimePicker"
                                value={new Date(date)}
                                mode={'date'}
                                is24Hour={true}
                                display="default"
                                accessibilityViewIsModal={false}
                                onChange={this.handleDateChange}

                            /> :
                                showDate && <DateTimePicker
                                    testID="dateTimePicker"
                                    value={new Date(date)}
                                    mode={'date'}
                                    is24Hour={true}
                                    display="default"
                                    accessibilityViewIsModal={false}
                                    onChange={this.handleDateChange}
                                    onTouchCancel={() => console.log(1)}
                                />
                        }
                        <Label style={{ marginTop: 10, marginBottom: 10 }}>Tải ảnh lên (03 ảnh)</Label>
                        <View style={{ flexDirection: "row", justifyContent: "center", marginBottom: 20 }}>
                            {images[0] === undefined ? <Button onPress={() => this.pickImage("0")} style={{ marginRight: 5 }} icon bordered>
                                <Icon name="image" type="FontAwesome" />
                            </Button> : <TouchableOpacity style={{ marginRight: 5 }} onPress={() => this.pickImage("0")}><Thumbnail square large source={{ uri: images[0].uri }} /></TouchableOpacity>}
                            {images[1] === undefined ? <Button onPress={() => this.pickImage("1")} style={{ marginRight: 5 }} icon bordered>
                                <Icon name="image" type="FontAwesome" />
                            </Button> : <TouchableOpacity style={{ marginRight: 5 }} onPress={() => this.pickImage("1")}><Thumbnail square large source={{ uri: images[1].uri }} /></TouchableOpacity>}
                            {images[2] === undefined ? <Button onPress={() => this.pickImage("2")} style={{ marginRight: 5 }} icon bordered>
                                <Icon name="image" type="FontAwesome" />
                            </Button> : <TouchableOpacity style={{ marginRight: 5 }} onPress={() => this.pickImage("2")}><Thumbnail square large source={{ uri: images[2].uri }} /></TouchableOpacity>}
                        </View>

                        <Button full style={{ borderRadius: 5 }} onPress={this.handleRequestFix}><Text uppercase={false}>Gởi yêu cầu</Text></Button>
                    </View>

                </Content>
                <Modal visible={scan}>
                    <ScanQR closeScreen={this.closeScreen} {...this.props} scanResult={(data) => this.scanResult(data)} />
                </Modal>
            </Container>
        );
    }
}

export default UserOrder;

const styles = StyleSheet.create({
    flex: {
        flex: 1
    },
    container: {
        position: 'relative'
    },
    emptyStay: {
        textAlign: 'center',
    },
    countBadge: {
        paddingHorizontal: 8.6,
        paddingVertical: 5,
        borderRadius: 30,
        position: 'absolute',
        right: 3,
        bottom: 3,
        justifyContent: 'center',
        backgroundColor: '#0580FF',
        width: 30,
        height: 30
    },
    countBadgeText: {
        fontWeight: 'bold',
        alignSelf: 'center',
        padding: 'auto',
        color: '#ffffff'
    }
});
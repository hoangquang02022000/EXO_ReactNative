import React, { Component } from 'react';
import { View, Text } from 'react-native';

class Report extends Component {
    constructor(props) {
        super(props);
        this.state = {
        };
    }

    render() {
        return (
            <View>
                <Text style={{textAlign:"center", marginTop:30}}> Chức năng đang xây dựng </Text>
            </View>
        );
    }
}

export default Report;

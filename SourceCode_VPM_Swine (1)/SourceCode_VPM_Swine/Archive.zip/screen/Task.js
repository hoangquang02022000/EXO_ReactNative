import React, { Component } from 'react';
import { Fragment } from 'react';
import { CheckUserRule, UserType } from '../func';
import Etask from './Engineers/Etask';
import MEtask from './ManageEngineers/MEtask';
import MUtask from './ManageUsers/MUtask';

class Task extends Component {
    state = {
        rule: ""
    }

    async componentDidMount() {
        let rule = await CheckUserRule();
        this.setState({ rule });
    }

    render() {
        let { rule } = this.state;
        let views = null;
        if (rule===UserType.ManageUser){
            views = <MUtask {...this.props}/>
        }
        if (rule===UserType.Engineer){
            views = <Etask {...this.props}/>
        }
        if (rule===UserType.ManageEngineer){
            views = <MEtask {...this.props}/>
        }
        return (
            <Fragment>
                {views}
            </Fragment>
        );
    }
}

export default Task;

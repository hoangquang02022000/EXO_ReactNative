import axios from "axios";
const apiKey = 'yhTMTlGGQyPKhlr8IHKMHc4mB7qo3R5t';

export const POST_DATA_WITHOUT_AUTH = (Url, Data, handleData) => {
    axios.post(Url, Data, {
        headers:{
            "content-type":"application/json",
            "host":"exp.host",
            "accept-encoding":"gzip, deflate",
            "accept": "application/json"
        }
    }).then(res => {
        handleData(res.data);
    });
}

export const GET_DATA = (Url, handleData) => {
    axios.get(Url, {
        headers: {
            'Authorization': apiKey
        }
    }).then(res => {
        handleData(res.data);
    });
}

export const GET_DATA_WITH_BODY = (Url, Body, handleData) => {
    axios.get(Url, {
        params: Body,
        headers: {
            'Authorization': apiKey
        }
    }).then(res => {
        handleData(res.data);
    });
}

export const POST_DATA = (Url, Data, handleData) => {
    axios.post(Url, Data, {
        headers: {
            'Authorization': apiKey
        }
    }).then(res => {
        handleData(res.data);
    });
}

export const POST_FORM_DATA = (Url, Data, handleData) => {
    axios.post(Url, Data, {
        headers: {
            'Content-Type': 'multipart/form-data',
            'Authorization': apiKey
        }
    }).then(res => {
        handleData(res.data);
    });
}

export const POST_DATA_LOGIN = (Url, Data, handleData) => {
    axios.post(Url, Data).then(res => {
        handleData(res.data);
    });
}
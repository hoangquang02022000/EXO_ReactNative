let DOMAIN = 'https://webservice.cp.com.vn/apivpmmobile/';
// let DOMAIN = 'http://172.21.73.64:8080/';
let API = DOMAIN + 'api/';
let IMAGE = DOMAIN + 'upload/';
export const Path = {
    API,
    IMAGE,
    Product: IMAGE + 'product/'
};
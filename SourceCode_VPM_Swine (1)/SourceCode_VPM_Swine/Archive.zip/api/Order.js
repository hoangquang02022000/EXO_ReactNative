import { Path } from './Path';
import { POST_DATA, GET_DATA, POST_FORM_DATA } from './Fetch';

export const Api = {
    _request: Path.API + 'PostFormData?'
}

export const UserRequestFix = (mc_code, error_code, date, userid, db_name, formData, handleData) => POST_FORM_DATA(
    Api._request + `mc_code=${mc_code}&error_code=${error_code}&date=${date}&userid=${userid}&db_name=${db_name}`,
    formData,
    res => {
        handleData(res)
    }
)

export const ApiLogin = (data, handleData) => POST_DATA(Api._login, data, res => {
    handleData(res);
});

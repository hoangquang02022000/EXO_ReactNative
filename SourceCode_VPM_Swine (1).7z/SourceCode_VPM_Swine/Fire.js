// import * as firebase from 'firebase';
// import 'firebase/firestore';

// const config = {
//     apiKey: "AIzaSyCBV5rB_XvCMkuXAFEcWiCZZ634is0N_As",
//     authDomain: "vpmfood-6bdb6.firebaseapp.com",
//     projectId: "vpmfood-6bdb6",
//     storageBucket: "vpmfood-6bdb6.appspot.com",
//     messagingSenderId: "968754037313",
//     appId: "1:968754037313:web:937c1201900f542b747cc0"
// }
// export const firebaseApp = !firebase.apps.length ? firebase.initializeApp(config) : firebase.app();
// export const fireStore = firebase.firestore();